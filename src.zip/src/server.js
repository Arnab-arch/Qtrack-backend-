import dotenv from "dotenv";
dotenv.config();

import cors from "cors";
import express from "express";
import pool from "./config/db.js";
import authRoutes from "./routes/api/authRoutes.js";
import locationRoutes from "./routes/api/locations.js";
import serviceRoutes from "./routes/api/services.js";
import queueRoutes from "./routes/api/queues.js";
import tokenRoutes from "./routes/api/tokens.js";

const app = express();
const PORT = process.env.PORT || 5000;

import { initDb } from "./config/schema.js";

app.use((req, res, next) => {
  if (req.method === "GET") res.set("Cache-Control", "no-store");
  next();
});

app.use(express.json());
app.use(cors());

app.use("/queues", queueRoutes);
app.use("/tokens", tokenRoutes);
app.use("/api/auth", authRoutes);
app.use("/locations", locationRoutes);
app.use("/services", serviceRoutes);

app.get("/", (req, res) => {
  res.send("QTrack API Running");
});

app.listen(PORT, () => {
  console.log(`server running on http://localhost:${PORT}`);
  initDb();
});


